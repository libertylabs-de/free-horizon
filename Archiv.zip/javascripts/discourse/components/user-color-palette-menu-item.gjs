import Component from "@glimmer/component";
import { action } from "@ember/object";
import { trustHTML } from "@ember/template";
import DButton from "discourse/ui-kit/d-button";
import dConcatClass from "discourse/ui-kit/helpers/d-concat-class";

export default class UserColorPaletteMenuItem extends Component {
  get siteStyle() {
    return `--icon-color: ${this.args.colorPalette.accent}`;
  }

  get activeClass() {
    if (this.args.selectedColorPaletteId === this.args.colorPalette.id) {
      return "active";
    }
  }

  @action
  paletteSelected() {
    this.args.paletteSelected(this.args.colorPalette);
  }

  <template>
    <div
      class="user-color-palette-menu__item"
      data-color-palette={{@colorPalette.name}}
    >
      <DButton
        class={{dConcatClass
          "btn-flat user-color-palette-menu__item-choice"
          this.activeClass
        }}
        style={{trustHTML this.siteStyle}}
        @icon="circle"
        @translatedLabel={{@colorPalette.name}}
        @action={{this.paletteSelected}}
      />
    </div>
  </template>
}
